import UIKit
import PlaygroundSupport

protocol RawProperties : class{
    init(a:String,b:String)
    var name : String {get set}
    var colour : String {get set}
    func printDetails()
}

class Fruits : RawProperties{
    required init(a: String, b: String) {
        name = a
        colour = b
    }
    var colour: String = ""
    
    func printDetails() {
        print("Name = \(name) and Colour = \(colour)")
    }
    
    var name: String = ""
//        willSet{
//            print("Value is about to change")
//        }
//        didSet{
//            print("Value changed")
//        }
    
}
    

class Vegetables : RawProperties{
    required init(a:String,b:String) {
        name = a
        colour = b
    }
    var name: String = ""
    var colour: String = ""
    func printDetails() {
        print("Name = \(name) and Colour = \(colour)")
    }
}

class Delegates {
    weak var delegate : RawProperties?
}

var fruit1 = Fruits(a:"Apple",b:"Red")
fruit1.name
fruit1.name = "Apple"
fruit1.colour = "Red"
fruit1.printDetails()
var vegetable1 = Vegetables(a:"LadyFinger",b:"Green")
vegetable1.name = "LadyFinger"
vegetable1.colour = "Green"
vegetable1.printDetails()
var delegates = Delegates()
delegates.delegate = fruit1
delegates.delegate?.printDetails()
delegates.delegate = vegetable1
delegates.delegate?.printDetails()
delegates.delegate?.name = "Drumsticks"
delegates.delegate?.printDetails()
vegetable1.printDetails()
