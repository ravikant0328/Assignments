import UIKit
import PlaygroundSupport

class Bicycle {
    //Type Property
    static let noOfTires : Int = 2
    var commuterNumbers: Int
    var tireWidth: Double
    var topSpeed: Double
    var name: String
    var gears: Int
    // final prevents it from being overridden
    final var color = "Blue"
    init() {
        tireWidth = 40.5
        topSpeed = 15.0
        name = "'Trek' bike"
        gears = 5
        commuterNumbers = 2
    }
    func go(distance: Double) {
        print("Went \(distance) km(s) at a top speed of \(topSpeed) km/h in my \(name)")
    }
    func noOfCommuter() {
        print ("No. of Commuter= \(commuterNumbers)")
    }
}

class MountainBike : Bicycle {
    lazy var price : String = {
        return ("Prices depend on the region and the model")
    }()
    
    //Overridding init function of super class
    override init() {
        super.init()
        tireWidth = 60.0
        name = "mountain bike"
        gears = 10
    }
    // Overridding parent class function
    override func go(distance: Double) {
        super.go(distance: distance)
        print("Did \(distance) km(s) on a mountain bike")
    }
    
    // Overridding parent variable using getter and setter
    override var topSpeed: Double {
        get {
            return super.topSpeed - 4.0
        }
        set {
            super.topSpeed = newValue
        }
    }
    override var commuterNumbers: Int{
        get{
            return super.commuterNumbers - 1
        }
        set{
            super.commuterNumbers = newValue
        }
    }
    
    // Property observer
    override var gears: Int {
        didSet {
            print("Gears was changed to \(gears)")
        }
    }
//    override func noOfCommuter() {
//        print("No. of Commuter= 1")
//    }
}

var mountainBike = MountainBike()
mountainBike.topSpeed = 6.0
print(mountainBike.topSpeed)
mountainBike.go(distance: 12.0)
var bicycle1=Bicycle()
print(bicycle1.color)
bicycle1.go(distance: 40)
print("Number of Tires=",Bicycle.noOfTires)
print(mountainBike.price)
bicycle1.noOfCommuter()
mountainBike.name
mountainBike.tireWidth
mountainBike.noOfCommuter()

