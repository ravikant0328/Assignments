//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport

var str = "Hello, playground"
extension String{
    func sayHello() -> String {
        return "Hello from the other side"
    }
}

print("Hi".sayHello())


protocol SomeProtocol {
    func printName()
}

class SomeClass {
      var delegate : SomeProtocol?

}

class SomeClass2 : SomeProtocol {

    func printName() {
        print ("Kant")}
}




var A = SomeClass()
var B = SomeClass2()

A.delegate = B
print(A.delegate?.printName())
A.delegate?.printName()
A.delegate?.printName()





