import UIKit

class Helper{
    private init() {}
    static let  shared = Helper()
    
    var state = "Active"
    func logState(){
        print("The curent helper state is : \(state)")
    }
}

let helper1 = Helper.shared

let helper2 = Helper.shared

helper1 === helper2

Helper.shared.state

helper1.state

Helper.shared.logState()

helper1.logState()

helper1.state = "inactive"

helper1.state

Helper.shared.state
