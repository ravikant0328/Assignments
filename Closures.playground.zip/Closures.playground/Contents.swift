//: Playground - noun: a place where people can play

import UIKit

func calculator (n1:Int,n2:Int,operation:(Int,Int)->Int)->Int{
    return operation(n1,n2)
}

calculator(n1: 3, n2: 4, operation: {(n1:Int,n2:Int)-> Int in
    return n1*n2
})

calculator(n1: 4, n2: 5, operation: {(n1,n2) in
    return n1*n2
})

calculator(n1: 5, n2: 6, operation: {(n1,n2) in n1*n2})

calculator(n1: 6, n2: 7){$0*$1}

//calculator(n1: 7, n2: 8,operation:>}
