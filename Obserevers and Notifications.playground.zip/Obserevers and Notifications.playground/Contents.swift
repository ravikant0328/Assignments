//: Playground - noun: a place where people can play

import UIKit

class Foo: NSObject {
    @objc dynamic var bar = 0
    
}

class MyObject {
    private var token: NSKeyValueObservation!
    
    var objectToObserve = Foo()
    init(){
        token = objectToObserve.observe(\.bar) { object, change in
            print("bar property is now \(object.bar)")
        }
    }
}


let a = MyObject()
a.objectToObserve.bar=20





