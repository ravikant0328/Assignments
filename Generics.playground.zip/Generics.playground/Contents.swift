//: Playground - noun: a place where people c
class foo <T> {
    var any : T?
    func doSomething<T: Numeric>(lhs : T , rhs : T) -> T {
        return lhs + rhs
    }
}

class bar<S> : foo<Double> {
    
    override func doSomething<T>(lhs: T, rhs: T) -> T where T : Numeric {
        return lhs * rhs
    }
}

let b = foo<Any>()
b.any = 12.23
b.doSomething(lhs: 1.323131,rhs: 12.3)
if b.any != nil{
b.doSomething(lhs: 12.3, rhs: b.any as! Double)
}

guard let a = b.any else {
    print ("Data Not present")
    return
}

//let q =
